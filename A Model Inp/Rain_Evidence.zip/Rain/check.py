from pathlib import Path
import json,hashlib,shutil,subprocess,sys,re
ROOT=Path('/workspace/scratch/11bec61098c2');out=ROOT/'rain_check'
def sections(p):
 d={};s=''
 for l in p.read_text(encoding='utf-8-sig').splitlines():
  l=l.split(';')[0].strip()
  if l.startswith('['):s=l.upper();d[s]=[]
  elif l:d.setdefault(s,[]).append(l.split())
 return d
records=[];base=sections(ROOT/'upload/branched.inp')
for name in ['branched.inp','branched-1.inp','branched-2.inp','branched-3.inp','branched-4.inp','branched-5.inp','branched_Changed.inp']:
 src=ROOT/'upload'/name;b=sections(src);opt=dict((r[0],r[1]) for r in b['[OPTIONS]']);g=b['[RAINGAGES]'][0];series=[r for r in b['[TIMESERIES]'] if r[0]==g[-1]];depth=sum(float(r[-1]) for r in series)*.25
 records.append(dict(file=name,sha256=hashlib.sha256(src.read_bytes()).hexdigest(),units=opt['FLOW_UNITS'],active_series=g[-1],depth_native=depth,depth_in=depth if opt['FLOW_UNITS']=='CFS' else depth/25.4,peak_intensity_native=max(float(r[-1]) for r in series),end_time=opt['END_TIME'],changed_sections=[s for s in sorted(set(base)|set(b)) if base.get(s)!=b.get(s)]))
(out/'inspection.json').write_text(json.dumps(records,indent=2))
for name in ['branched.inp','branched-4.inp','branched_Changed.inp']:
 target=out/name;shutil.copyfile(ROOT/'upload'/name,target)
 code='from swmm.toolkit import solver; import sys; solver.swmm_run(sys.argv[1],sys.argv[2],sys.argv[3])'
 p=subprocess.run([sys.executable,'-c',code,str(target),str(target.with_suffix('.rpt')),str(target.with_suffix('.out'))],capture_output=True,text=True,timeout=120)
 (out/(target.stem+'.log')).write_text(p.stdout+'\n'+p.stderr)
 print(name,'exit',p.returncode,flush=True)
 if p.returncode:print(p.stderr,flush=True)
print(json.dumps(records,indent=2))
